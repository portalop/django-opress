﻿from django.contrib import admin
from pages.models import Pagina
from photologue.models import Photo

class PaginaAdmin(admin.ModelAdmin):
    search_fields = ['titulo']

admin.site.register(Pagina, PaginaAdmin)
